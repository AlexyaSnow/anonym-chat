const path = require("path");
const express = require("express");
const http = require("http");
const WebSocket = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: "/ws" });

const PUBLIC_DIR = path.join(__dirname, "public");
app.use(express.static(PUBLIC_DIR));

const connectedUsers = new Map();
const messages = new Map();
const typingUsers = new Set();
const lastMsg = new Map();
const reactions = new Map();
let messageCounter = 0;
let roomTopic = "Welcome to Anonym - Salle Tiktok 🎭";

const ROOM_NAME = "Tiktok";
const DEFAULT_TTL = 3600;
const TYPING_TIMEOUT = 3000;

function broadcastUserList() {
  const users = Array.from(connectedUsers.values()).map(u => u.username);
  const msg = JSON.stringify({ type: "user_list", users });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function broadcastTopic() {
  const msg = JSON.stringify({ type: "topic", topic: roomTopic });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function broadcastTypingStatus() {
  const typingList = Array.from(typingUsers);
  const msg = JSON.stringify({ type: "typing", users: typingList });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function broadcastUserJoinLeave(username, action) {
  const msg = JSON.stringify({
    type: "user_event",
    action: action,
    username: username,
    timestamp: new Date().toLocaleTimeString()
  });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function broadcastReaction(messageId, emoji, reactions_data) {
  const msg = JSON.stringify({
    type: "reaction",
    messageId: messageId,
    reactions: reactions_data
  });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

wss.on("connection", (ws) => {
  const userId = Math.random().toString(36).slice(2, 10);
  const username = "user-" + userId.slice(0, 6);
  
  connectedUsers.set(userId, { username, connectedAt: Date.now() });
  ws._id = userId;
  ws._username = username;
  ws._typingTimeout = null;

  broadcastUserList();
  broadcastTopic();
  broadcastUserJoinLeave(username, "join");

  ws.on("message", (raw) => {
    const now = Date.now();
    let pkt;
    try {
      pkt = JSON.parse(raw.toString());
    } catch {
      return;
    }

    if (pkt.type === "topic_change") {
      roomTopic = pkt.topic.slice(0, 200);
      broadcastTopic();
      return;
    }

    if (pkt.type === "typing") {
      if (!typingUsers.has(username)) {
        typingUsers.add(username);
        broadcastTypingStatus();
      }
      clearTimeout(ws._typingTimeout);
      ws._typingTimeout = setTimeout(() => {
        typingUsers.delete(username);
        broadcastTypingStatus();
      }, TYPING_TIMEOUT);
      return;
    }

    if (pkt.type === "reaction") {
      const { messageId, emoji, action } = pkt;
      if (!reactions.has(messageId)) {
        reactions.set(messageId, { "👍": [], "👎": [], "😂": [] });
      }
      const reactionMap = reactions.get(messageId);
      if (!reactionMap[emoji]) reactionMap[emoji] = [];
      if (action === "add") {
        if (!reactionMap[emoji].includes(username)) {
          reactionMap[emoji].push(username);
        }
      } else if (action === "remove") {
        reactionMap[emoji] = reactionMap[emoji].filter(u => u !== username);
      }
      broadcastReaction(messageId, emoji, reactionMap);
      return;
    }

    const last = lastMsg.get(userId) || 0;
    if (now - last < 800) return;
    lastMsg.set(userId, now);

    if (pkt.type === "chat" || pkt.room) {
      pkt.room = ROOM_NAME;
      const messageId = "msg-" + (messageCounter++);
      const ttl = pkt.ttl || DEFAULT_TTL;
      
      messages.set(messageId, {
        id: messageId,
        from: username,
        text: pkt.payload ? pkt.payload : pkt.text,
        timestamp: new Date().toLocaleTimeString(),
        ttl: ttl,
        createdAt: now
      });

      reactions.set(messageId, { "👍": [], "👎": [], "😂": [] });

      const out = JSON.stringify({
        type: "message",
        messageId: messageId,
        ...pkt,
        timestamp: new Date().toLocaleTimeString()
      });

      for (const client of wss.clients) {
        if (client.readyState === WebSocket.OPEN) client.send(out);
      }

      setTimeout(() => {
        messages.delete(messageId);
      }, ttl * 1000);
    }
  });

  ws.on("close", () => {
    clearTimeout(ws._typingTimeout);
    connectedUsers.delete(userId);
    typingUsers.delete(username);
    lastMsg.delete(userId);
    broadcastUserList();
    broadcastUserJoinLeave(username, "leave");
    broadcastTypingStatus();
  });

  ws.on("error", (err) => {
    console.error("WS Error:", err);
  });
});

const PORT = process.env.PORT || 3000;
const HOST = "0.0.0.0";

server.listen(PORT, HOST, () => {
  console.log(`✅ Serveur prêt sur le port ${PORT}`);
  console.log(`📡 Support 1000+ utilisateurs`);
});
